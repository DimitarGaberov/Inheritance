﻿using System.Collections.Generic;

public class StackOfStrings
{
    private List<string> data;

    public void Push(string element)
    {

    }

    public string Pop()
    {
        return "";
    }

    public string Peek()
    {
        return "";
    }

    public bool IsEmpty()
    {
        return true;
    }
}
